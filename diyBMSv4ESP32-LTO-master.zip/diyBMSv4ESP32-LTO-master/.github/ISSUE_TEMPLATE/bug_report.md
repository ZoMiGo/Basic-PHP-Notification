---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Hardware/Software Versions**
Controller version (from PCB): ??
(below can be obtained from the "About" page in the controller web interface)
Processor: ??
Version: ???
Compiled: ??

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error
