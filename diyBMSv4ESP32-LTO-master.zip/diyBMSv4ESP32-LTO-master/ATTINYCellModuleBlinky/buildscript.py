Import("env")

env.Replace(PROGNAME="diybms_module_firmware_blinky")

