// This is an automatically generated file, any changes will be overwritten on compiliation!
// DO NOT CHECK THIS INTO SOURCE CONTROL


#ifndef EmbeddedFiles_Defines_H
#define EmbeddedFiles_Defines_H

static const char GIT_VERSION[] = "LocalCompile";

static const char GIT_VERSION_SHORT[] = "LocalCompile";

static const uint16_t GIT_VERSION_B1 = 0xFFFF;

static const uint16_t GIT_VERSION_B2 = 0xFFFF;

static const char COMPILE_DATE_TIME[] = "2025-01-31T17:44:43.546Z";

static const char COMPILE_DATE_TIME_SHORT[] = "31 Jan 2025 17:44";

static const uint8_t COMPILE_YEAR_BYTE = 25;

static const uint8_t COMPILE_WEEK_NUMBER_BYTE = 4;

const char COMPILE_DATE_TIME_UTC[] = "2025-01-31T17:44:43.546Z";

const uint32_t COMPILE_DATE_TIME_UTC_EPOCH = 1738341883UL;

#endif