// This is an automatically generated file, any changes will be overwritten on compiliation!


#ifndef EmbeddedFiles_Integrity_H
#define EmbeddedFiles_Integrity_H

const char* const integrity_file_echarts_min_js = "sha256-XrZWnq5Baf6ekRMOjncs5eXIAhgRX7tzkT/mQiBn3uM=";
const char* const integrity_file_jquery_js = "sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=";
const char* const integrity_file_lang_de_js = "sha256-IT5ASVpXQQeY6CMWtgcD6XKNuW4Pcv4BIvgCVm0NkoM=";
const char* const integrity_file_lang_en_js = "sha256-lu4OV+3vmmWRVs+Qec9jacL3f5CSZxRCVQaVQDp8wJw=";
const char* const integrity_file_lang_es_js = "sha256-P32Rmrkpcwj+tznnCKn2a1udQc8Z292x48c7fr5NGGM=";
const char* const integrity_file_lang_fr_js = "sha256-WnbDvC8Czen1ktIiuPmkp3VQExlJmShEO3n1t5EKP/o=";
const char* const integrity_file_lang_hr_js = "sha256-s8DIMs7mVTfYtNbcj8lFKmyCMQb9CnfyWwqkbyINojU=";
const char* const integrity_file_lang_nl_js = "sha256-gAG8aV6R42TiFlbVS4rjlww7SBCLff+LltCIJKeY+sQ=";
const char* const integrity_file_lang_pt_js = "sha256-sYaVxBj0sFrnL//nbmRUddeL0bzx36IsF49VzZagqE4=";
const char* const integrity_file_lang_ru_js = "sha256-K/Z3VZl3XVitIU3GDiA/Dn+zUCY+X++P11wniOH/XJU=";
const char* const integrity_file_notify_min_js = "sha256-I++/1nqPBafgd4eTJsC/2NswzKU7rsks7EvUwDtDEEo=";
const char* const integrity_file_pagecode_js = "sha256-H79DbX7F++Ysf8iizhP/Mp3zHSZVwb6T5QrBFTK8BVc=";
#endif