// This is an automatically generated file, any changes will be overwritten on compiliation!
// DO NOT CHECK THIS INTO SOURCE CONTROL


#ifndef EmbeddedFiles_Defines_H
#define EmbeddedFiles_Defines_H

static const char GIT_VERSION[] = "6e62d616aa642884cb6458c0baf8057ccf2c11d6";

static const uint16_t GIT_VERSION_B1 = 0xcf2c;

static const uint16_t GIT_VERSION_B2 = 0x11d6;

static const char COMPILE_DATE_TIME[] = "2024-08-02T12:18:35.609Z";

#endif